<?php

class post extends
{
  
 
  
  
}
