

	

	<div class="row">

     

      <div class="col s12 m5 l4"><p></p></div>
   

      	<div class="col s12 m4">
   		 <div class="card">
            <div class="card-image">
              <img width="250" height="250"src="././images/404.jpg">
              <span class="card-title">Oh noooon...</span>
            </div>
            <div class="card-content">
              <p>Il semblerait qu'une erreur se soit produite lors du chargement de votre profil...</p>
            </div>
            
          </div>
          </div>
    <div class="col s12 m5 l4"><p></p></div>
      
     

    </div>