<p>Votre inscription a bien été prise en compte.</br>
Vous allez être automatiquement redirigé vers votre profil.</br>
Veuillez patienter...</p>
<script>setTimeout('window.location=\"userSuccess.php\"', 5000)</script>