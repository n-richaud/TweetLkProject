

	

	<div class="row">

      <div class="col s3">
        
      </div>

      <div class="col s12 m4 l2"><p></p></div>
    <div class="col s12 m4 l8"><p><h2>Formulaire d'identification</h2> <form method="post" action="ApiTest.php?action=login" enctype="multipart/form-data">
		<p>Veuillez entrer vos identifiants :</p>
		<p><input type="text" name="user" placeholder="Identifiant" />
		<input type="password" name="pass" placeholder="Mot de Passe" />
		<button class="light-blue darken-4 btn waves-effect waves-light" type="submit" name="button_action">
	  		  Se connecter
	 		 </button>
		</p></form></div>
    <div class="col s12 m4 l2"><p></p></div>
      
      

    </div>