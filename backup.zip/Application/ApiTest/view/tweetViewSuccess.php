<table>
 
  <tr>
    <th colspan="2">Tweet from user :</th>  </tr>
  <tr>
    <td colspan="2">Zombie ipsum reversus ab viral inferno, nam rick grimes malum cerebro.</td>

  </tr>
  <tr><td class="tweetText">Vote : 42 </td><td> Partage : 23</td></tr>
</table>