
        
<div class="row">
            
              
          </div>





  <div class="parallax-container">
    <div class="parallax"><img src="././images/wall-parallax.jpg"></div>
  </div>
  <div class="section white">
    <div class="row container">
      <div class="center promo ">
                <div class="col s4">
                <i class="material-icons large">language</i>
                <p class="promo-caption">Développement accéléré</p>
                <p class="light center">We did most of the heavy lifting for you to provide a default stylings that incorporate our custom components.</p>
              </div>
            
            <div class="col s4">
              <div class="center promo ">
                <i class="material-icons large">group</i>
                <p class="promo-caption">Centré sur l'experience utilisateur</p>
                <p class="light center">By utilizing elements and principles of Material Design, we were able to create a framework that focuses on User Experience.</p>
              </div>
            </div>
            <div class="col s4">
              <div class="center promo ">
                <i class="material-icons large">chat_bubble_outline</i>
                <p class="promo-caption">Facile à prendre en main</p>
                <p class="light center">We have provided detailed documentation as well as specific code examples to help new users get started.</p>
              </div>
            </div>
      </div>
  </div>
  </div>